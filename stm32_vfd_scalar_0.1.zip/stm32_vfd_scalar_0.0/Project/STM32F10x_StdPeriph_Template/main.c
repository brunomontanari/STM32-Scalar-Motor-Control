/**
******************************************************************************
* @file    Project/STM32F10x_StdPeriph_Template/main.c 
* @author  Bruno Montanari
* @version V3.5.0
* @date    04-May-2016
* @brief   Main program body
******************************************************************************
* @attention
*
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
* TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
* DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
* FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
* CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*
* <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
******************************************************************************
*/  

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "MC_const.h"
#include "MC_type.h"

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
USART_InitTypeDef USART_InitStructure;

/* Private function prototypes -----------------------------------------------*/
#ifdef __GNUC__
/* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
set to 'Yes') calls __io_putchar() */
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */

/* Private functions ---------------------------------------------------------*/
void RampTurnOn(void);
void RampTurnOff(void);
/**
* @brief  Main program.
* @param  None
* @retval None
*/


#define LED3_GPIO_PORT          GPIOB
#define LED3_GPIO_CLK           RCC_APB2Periph_GPIOB		
#define LED3_GPIO_PIN           GPIO_Pin_2

#define LED4_GPIO_PORT          GPIOA
#define LED4_GPIO_CLK           RCC_APB2Periph_GPIOA		
#define LED4_GPIO_PIN           GPIO_Pin_5

#define BTN_GPIO_PORT          GPIOC
#define BTN_GPIO_CLK           RCC_APB2Periph_GPIOC		
#define BTN_GPIO_PIN           GPIO_Pin_13

void GPIO_Setup_Add()
{         
  GPIO_InitTypeDef  GPIO_InitStructure;
  
  RCC_APB2PeriphClockCmd(LED4_GPIO_CLK, ENABLE);
  GPIO_InitStructure.GPIO_Pin = LED4_GPIO_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(LED4_GPIO_PORT, &GPIO_InitStructure);
  
  RCC_APB2PeriphClockCmd(LED3_GPIO_CLK, ENABLE);
  GPIO_InitStructure.GPIO_Pin = LED3_GPIO_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(LED3_GPIO_PORT, &GPIO_InitStructure);
  
  
  // initialization of PA0 for input
  RCC_APB2PeriphClockCmd(BTN_GPIO_CLK, ENABLE);
  GPIO_InitStructure.GPIO_Pin = BTN_GPIO_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(BTN_GPIO_PORT, &GPIO_InitStructure);
  
  
  // pin for sync
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
}

void GPIO_Set_Led3(unsigned char On)
{
  if (On)
    LED3_GPIO_PORT->BSRR = LED3_GPIO_PIN; 
  else
    LED3_GPIO_PORT->BRR = LED3_GPIO_PIN;
}

void GPIO_Set_Led4(unsigned char On)
{
  if (On)
    LED4_GPIO_PORT->BSRR = LED4_GPIO_PIN; 
  else
    LED4_GPIO_PORT->BRR = LED4_GPIO_PIN;
}

void GPIO_Set_Sync(unsigned char On)
{
  if (On)
    GPIOB->BSRR = GPIO_Pin_10; 
  else
    GPIOB->BRR = GPIO_Pin_10;
}

unsigned char GPIO_GetBtn()
{
  return GPIO_ReadInputDataBit(BTN_GPIO_PORT, BTN_GPIO_PIN);
}

/****	Power devices switching frequency  ****/
#define PWM_FREQ ((u16) 14400)          // in Hz  (N.b.: pattern type is center aligned)

/****    Deadtime Value   ****/
//#define DEADTIME_NS	((u16) 800)         //in nsec 
#define DEADTIME_NS	((u16) 1000)         //in nsec 


/////////////////////// PWM Peripheral Input clock ////////////////////////////
#define CKTIM	((u32)24000000uL) 	/* Silicon running at 60MHz Resolution: 1Hz */

////////////////////// PWM Frequency ///////////////////////////////////

/****	 Pattern type is center aligned  ****/

#define PWM_PRSC ((u8)0)

/* Resolution: 1Hz */                            
#define PWM_PERIOD ((u16) (CKTIM / (u32)(2 * PWM_FREQ *(PWM_PRSC+1)))) 

////////////////////////////// Deadtime Value /////////////////////////////////
#define DEADTIME  (u16)((unsigned long long)CKTIM/2 \
*(unsigned long long)DEADTIME_NS/1000000000uL) 

/****	ADC IRQ-HANDLER frequency, related to PWM  ****/
// ?????????????????? !!! whats that!
#define REP_RATE (1)  // (N.b): Internal current loop is performed every 
//             (REP_RATE + 1)/(2*PWM_FREQ) seconds.
// In case of three-shunt current reading:
// - REP_RATE must be an odd number 
// - REP_RATE must be higher than 1 for PWM_FREQ > 12500     
// These limitations don't apply to ICS

void SVPWM_Init()
{
  TIM_TimeBaseInitTypeDef TIM1_TimeBaseStructure;
  TIM_OCInitTypeDef TIM1_OCInitStructure;
  TIM_BDTRInitTypeDef TIM1_BDTRInitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
  
  /* ADC1, ADC2, DMA, GPIO, TIM1 clocks enabling -----------------------------*/
  
  /* ADCCLK = PCLK2/6 */
  RCC_ADCCLKConfig(RCC_PCLK2_Div6);
  
  /* Enable DMA clock */
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
  
  /* Enable ADC1 clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
  
  /* Enable ADC2 clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, ENABLE);
  
  /* Enable GPIOA-GPIOE clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOA | 
                         RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD |
                           RCC_APB2Periph_GPIOE, ENABLE);
  
  /* Enable TIM1 clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
  
  
  /* TIM1 Peripheral Configuration -------------------------------------------*/
  /* TIM1 Registers reset */
  TIM_DeInit(TIM1);
  TIM_TimeBaseStructInit(&TIM1_TimeBaseStructure);
  /* Time Base configuration */
  TIM1_TimeBaseStructure.TIM_Prescaler = PWM_PRSC;
  TIM1_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_CenterAligned1;
  TIM1_TimeBaseStructure.TIM_Period = PWM_PERIOD;
  TIM1_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV2;
  TIM1_TimeBaseStructure.TIM_RepetitionCounter = REP_RATE;
  TIM_TimeBaseInit(TIM1, &TIM1_TimeBaseStructure);
  
  TIM_OCStructInit(&TIM1_OCInitStructure);
  /* Channel 1, 2,3 and 4 Configuration in PWM mode */
  TIM1_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
  TIM1_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 
  TIM1_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable;                  
  TIM1_OCInitStructure.TIM_Pulse = 0x505; //dummy value
  TIM1_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; 
  TIM1_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High;         
  TIM1_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Reset;
  TIM1_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Reset;          
  
  TIM_OC1Init(TIM1, &TIM1_OCInitStructure); 
  
  TIM1_OCInitStructure.TIM_Pulse = 0x505; //dummy value
  TIM_OC2Init(TIM1, &TIM1_OCInitStructure);
  
  TIM1_OCInitStructure.TIM_Pulse = 0x505; //dummy value
  TIM_OC3Init(TIM1, &TIM1_OCInitStructure);
  
  GPIO_StructInit(&GPIO_InitStructure);  
  
  /* GPIOE Configuration: Channel 1, 2, 3 Output */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure); 
  
  /* GPIOE Configuration: Channel 1N, 2N, 3N Output */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure); 
  
  /* Lock CH1-CH3 pins */ //BFM should be GPIOA
  GPIO_PinLockConfig(GPIOB, GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10);
  GPIO_StructInit(&GPIO_InitStructure);
  
  /* Automatic Output enable, Break, dead time and lock configuration*/
  TIM1_BDTRInitStructure.TIM_OSSRState = TIM_OSSRState_Enable;
  TIM1_BDTRInitStructure.TIM_OSSIState = TIM_OSSIState_Enable;
  TIM1_BDTRInitStructure.TIM_LOCKLevel = TIM_LOCKLevel_1; 
  TIM1_BDTRInitStructure.TIM_DeadTime = DEADTIME;
  TIM1_BDTRInitStructure.TIM_Break = TIM_Break_Disable;  
  TIM1_BDTRInitStructure.TIM_BreakPolarity = TIM_BreakPolarity_Low;
  TIM1_BDTRInitStructure.TIM_AutomaticOutput = TIM_AutomaticOutput_Disable;
  
  TIM_BDTRConfig(TIM1, &TIM1_BDTRInitStructure);
  
  TIM_SelectOutputTrigger(TIM1, TIM_TRGOSource_Update);
  
  //  TIM_ClearITPendingBit(TIM1, TIM_IT_Break);
  //  TIM_ITConfig(TIM1, TIM_IT_Break, ENABLE);
  
  /* TIM1 counter enable */
  TIM_Cmd(TIM1, ENABLE);
  TIM_CtrlPWMOutputs( TIM1, ENABLE);
}


void Adc_Init(void)
{
  ADC_InitTypeDef  ADC_InitStructure;
  /* PCLK2 is the APB2 clock */
  /* ADCCLK = PCLK2/6 = 72/6 = 12MHz*/
  RCC_ADCCLKConfig(RCC_PCLK2_Div6);
  
  /* Enable ADC1 clock so that we can talk to it */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
  /* Put everything back to power-on defaults */
  ADC_DeInit(ADC1);
  
  /* ADC1 Configuration ------------------------------------------------------*/
  /* ADC1 and ADC2 operate independently */
  ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
  /* Disable the scan conversion so we do one at a time */
  ADC_InitStructure.ADC_ScanConvMode = DISABLE;
  /* Don't do contimuous conversions - do them on demand */
  ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
  /* Start conversin by software, not an external trigger */
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
  /* Conversions are 12 bit - put them in the lower 12 bits of the result */
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  /* Say how many channels would be used by the sequencer */
  ADC_InitStructure.ADC_NbrOfChannel = 1;
  
  /* Now do the setup */
  ADC_Init(ADC1, &ADC_InitStructure);
  /* Enable ADC1 */
  ADC_Cmd(ADC1, ENABLE);
  
  /* Enable ADC1 reset calibaration register */
  ADC_ResetCalibration(ADC1);
  /* Check the end of ADC1 reset calibration register */
  while(ADC_GetResetCalibrationStatus(ADC1));
  /* Start ADC1 calibaration */
  ADC_StartCalibration(ADC1);
  /* Check the end of ADC1 calibration */
  while(ADC_GetCalibrationStatus(ADC1));
}

int Adc_Read(u8 channel)
{
  //u8 channel = 0;
  //u8 channel = 10;
  ADC_RegularChannelConfig(ADC1, channel, 1, ADC_SampleTime_1Cycles5);
  // Start the conversion
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);
  // Wait until conversion completion
  while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
  // Get the conversion value
  return ADC_GetConversionValue(ADC1);
}

unsigned int iAccumulator = 0;
volatile unsigned int iFreqCode = 0;
volatile unsigned char cBotState = Bit_SET;
volatile unsigned char cRampTurnOnOff = 0;

int main(void)
{
  RCC_ClocksTypeDef RCC_Clocks;
  
  /* SystTick configuration: an interrupt every 100us */
  RCC_GetClocksFreq(&RCC_Clocks);
  SysTick_Config(RCC_Clocks.SYSCLK_Frequency / 10000);
  
  /* Update the SysTick IRQ priority should be higher than the Ethernet IRQ */
  /* The Localtime should be updated during the Ethernet packets processing */
  NVIC_SetPriority (SysTick_IRQn, 1);
  
  
  GPIO_Setup_Add();
  SVPWM_Init();
  
  Adc_Init();
  
  
  /* USARTx configured as follow:
  - BaudRate = 115200 baud  
  - Word Length = 8 Bits
  - One Stop Bit
  - No parity
  - Hardware flow control disabled (RTS and CTS signals)
  - Receive and transmit enabled
  
  USART_InitStructure.USART_BaudRate = 115200;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  
  STM_EVAL_COMInit(COM1, &USART_InitStructure);
  */
  /* Initialize the LCD */
  
  
  /* Infinite loop */
  while (1)
  {
//    if(cBotState == Bit_RESET)
//    {
//      if(cRampTurnOnOff == TURN_ON)
//      {
//        RampTurnOn();
//      }
//      else if (cRampTurnOnOff == TURN_OFF)
//      {
//        RampTurnOff();
//      }
//      cBotState = Bit_SET;
//    }
//    if (cRampTurnOnOff == TURN_POT)
//    {
      iFreqCode = Adc_Read(13)*5243;
//    } 
  }
}



Volt_Components Stat_Volt_alfa_beta;        /*Valpha & Vbeta, RevPark transformations
of Vq & Vd*/

#define SQRT_3		1.732051
#define T		(PWM_PERIOD * 4)
#define T_SQRT3         (u16)(T * SQRT_3)

#define SECTOR_1	(u32)1
#define SECTOR_2	(u32)2
#define SECTOR_3	(u32)3
#define SECTOR_4	(u32)4
#define SECTOR_5	(u32)5
#define SECTOR_6	(u32)6

/*******************************************************************************
* Function Name  : SVPWM_IcsCalcDutyCycles
* Description    : Computes duty cycle values corresponding to the input value
and configures 
* Input          : Stat_Volt_alfa_beta
* Output         : None
* Return         : None
*******************************************************************************/

void SVPWM_IcsCalcDutyCycles (Volt_Components Stat_Volt_Input)
{
  u8 bSector;
  s32 wX, wY, wZ, wUAlpha, wUBeta;
  u16  hTimePhA=0, hTimePhB=0, hTimePhC=0;
  
  wUAlpha = Stat_Volt_Input.qV_Component1 * T_SQRT3 ;
  wUBeta = -(Stat_Volt_Input.qV_Component2 * T);
  
  wX = wUBeta;
  wY = (wUBeta + wUAlpha)/2;
  wZ = (wUBeta - wUAlpha)/2;
  
  // Sector calculation from wX, wY, wZ
  if (wY<0)
  {
    if (wZ<0)
    {
      bSector = SECTOR_5;
    }
    else // wZ >= 0
      if (wX<=0)
      {
        bSector = SECTOR_4;
      }
      else // wX > 0
      {
        bSector = SECTOR_3;
      }
  }
  else // wY > 0
  {
    if (wZ>=0)
    {
      bSector = SECTOR_2;
    }
    else // wZ < 0
      if (wX<=0)
      {  
        bSector = SECTOR_6;
      }
      else // wX > 0
      {
        bSector = SECTOR_1;
      }
  }
  
  /* Duty cycles computation */
  
  switch(bSector)
  {  
  case SECTOR_1:
  case SECTOR_4:
    hTimePhA = (T/8) + ((((T + wX) - wZ)/2)/131072);
    hTimePhB = hTimePhA + wZ/131072;
    hTimePhC = hTimePhB - wX/131072;                                       
    break;
  case SECTOR_2:
  case SECTOR_5:  
    hTimePhA = (T/8) + ((((T + wY) - wZ)/2)/131072);
    hTimePhB = hTimePhA + wZ/131072;
    hTimePhC = hTimePhA - wY/131072;
    break;
    
  case SECTOR_3:
  case SECTOR_6:
    hTimePhA = (T/8) + ((((T - wX) + wY)/2)/131072);
    hTimePhC = hTimePhA - wY/131072;
    hTimePhB = hTimePhC + wX/131072;
    break;
  default:
    break;
  }
  
  /* Load compare registers values */
  
  TIM1->CCR1 = hTimePhA;
  TIM1->CCR2 = hTimePhB;
  TIM1->CCR3 = hTimePhC;
}


u8 iTableAddr = 0; 
//static s16 hSin_Theta,*/ hCos_Theta;
const s16 hSin_Cos_Table[256] = SIN_COS_TABLE;

void UpdatePWM()
{
  iAccumulator = iAccumulator + iFreqCode;
  
  iTableAddr = iAccumulator >> 24;
  Stat_Volt_alfa_beta.qV_Component1 = hSin_Cos_Table[(iTableAddr+OFFSET)&0xFF] / 2;
  Stat_Volt_alfa_beta.qV_Component2 = hSin_Cos_Table[iTableAddr] / 2;
  SVPWM_IcsCalcDutyCycles(Stat_Volt_alfa_beta);
  
  if (Stat_Volt_alfa_beta.qV_Component2 & 0x8000) 
  { 
    GPIO_Set_Led4(1); 
    GPIO_Set_Sync(1); 
  } 
  else 
  { 
    GPIO_Set_Led4(0); 
    GPIO_Set_Sync(0); 
  }
}

extern volatile unsigned int iRampTick;
void RampTurnOn(void)
{
  unsigned int iFreq;
  iFreq = iFreqCode/5243; //get the current frequency
  while (iFreq < 4095)
  {
    if(!iRampTick)   
    {
      iFreq +=163; //2Hz upgrade in final frequency
      iFreqCode = iFreq*5243;
      iRampTick = 1000;
    }   
  }
 
}

void RampTurnOff(void)
{
  unsigned int iFreq;
  iFreq = iFreqCode/5243; //get the current frequency
  while (iFreq > 165 )
  {
    if(!iRampTick)   
    {
      iFreq -=163; //2Hz decrement in the final frequency
      iFreqCode = iFreq*5243;
      iRampTick = 1000;
    }   
  }
  iFreqCode = 0;
}
/**
* @brief  Retargets the C library printf function to the USART.
* @param  None
* @retval None

PUTCHAR_PROTOTYPE
{
// Place your implementation of fputc here
// e.g. write a character to the USART 
USART_SendData(EVAL_COM1, (uint8_t) ch);

// Loop until the end of transmission
while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET)
{}

return ch;
}
*/

#ifdef  USE_FULL_ASSERT

/**
* @brief  Reports the name of the source file and the source line number
*         where the assert_param error has occurred.
* @param  file: pointer to the source file name
* @param  line: assert_param error line source number
* @retval None
*/
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
  ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  
  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
* @}
*/


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/

